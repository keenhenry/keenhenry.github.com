import java.util.*;
/**
 * classification tree for HW2
 * @author Joey
 *
 */
public class classificationTree {

	
	static private classificationTree mTree = null;
	private cNode mRoot = null;
	/**
	 * obtain tree instance(Use this method to obtain tree)
	 * @return
	 */
	static public classificationTree getTree(){
		if(mTree == null){
			// build tree if first time
			mTree = new classificationTree();
		}
		
		return mTree;
	}
	/**
	 * return root node
	 * @return
	 */
	public cNode getRoot(){
		return mRoot;
	}
	/**
	 * tree constructor
	 */
	private classificationTree(){
		// init root node
		mRoot = new cNode();
		mRoot.setClassName("Root");
		// init computer node
		cNode Computers = new cNode();
		Computers.setClassName("Computers");
		for(int i=0;i<KeyWords.computerK.length;i++){
			Computers.addQueryWord(KeyWords.computerK[i]);
		}
		// init health node
		cNode Health = new cNode();
		Health.setClassName("Health");
		for(int i=0;i<KeyWords.HealthK.length;i++){
			Health.addQueryWord(KeyWords.HealthK[i]);
		}
		// init sport node
		cNode Sports = new cNode();
		Sports.setClassName("Sports");
		for(int i=0;i<KeyWords.SportsK.length;i++){
			Sports.addQueryWord(KeyWords.SportsK[i]);
		}
		// init hardware node
		cNode hardware = new cNode();
		hardware.setClassName("Hardware");
		for(int i=0;i<KeyWords.HardwareK.length;i++){
			hardware.addQueryWord(KeyWords.HardwareK[i]);
		}
		hardware.setLeaf();
		// init Programming node
		cNode Programming = new cNode();
		Programming.setClassName("Programming");
		for(int i=0;i<KeyWords.ProgrammingK.length;i++){
			Programming.addQueryWord(KeyWords.ProgrammingK[i]);
		}
		Programming.setLeaf();
		// init Diseases node
		cNode Diseases = new cNode();
		Diseases.setClassName("Diseases");
		for(int i=0;i<KeyWords.DiseasesK.length;i++){
			Diseases.addQueryWord(KeyWords.DiseasesK[i]);
		}
		Diseases.setLeaf();
		// init Fitness node
		cNode Fitness = new cNode();
		Fitness.setClassName("Fitness");
		for(int i=0;i<KeyWords.FitnessK.length;i++){
			Fitness.addQueryWord(KeyWords.FitnessK[i]);
		}
		Fitness.setLeaf();
		// init Soccer node
		cNode Soccer = new cNode();
		Soccer.setClassName("Soccer");
		for(int i=0;i<KeyWords.SoccerK.length;i++){
			Soccer.addQueryWord(KeyWords.SoccerK[i]);
		}
		Soccer.setLeaf();
		// init Basketball node
		cNode Basketball = new cNode();
		Basketball.setClassName("Basketball");
		for(int i=0;i<KeyWords.BasketballK.length;i++){
			Basketball.addQueryWord(KeyWords.BasketballK[i]);
		}
		Basketball.setLeaf();
		Computers.addChild(hardware);
		Computers.addChild(Programming);
		Health.addChild(Diseases);
		Health.addChild(Fitness);
		Sports.addChild(Soccer);
		Sports.addChild(Basketball);
		mRoot.addChild(Computers);
		mRoot.addChild(Health);
		mRoot.addChild(Sports);
	}
	/**
	 * tree node
	 * @author Joey
	 *
	 */
	protected static class cNode{
		private String className;
		private Vector<String> queryWords = new Vector<String>();
		private Vector<cNode> childrenList = new Vector<cNode>();
		private boolean isLeaf = false;
		
		private void setClassName(String name){
			className = name;
		}
		private void addQueryWord(String word){
			queryWords.add(word);
		}
		private void addChild(cNode child){
			childrenList.add(child);
		}
		private void setLeaf(){
			isLeaf = true;
		}
		public String getClassName(){
			return className;
		}

		public Vector<String> getQueryWords(){
			return queryWords;
		}

		public Vector<cNode> getChildren(){
			return childrenList;
		}
		public boolean isLeaf(){
			return isLeaf;
		}
	}
}
