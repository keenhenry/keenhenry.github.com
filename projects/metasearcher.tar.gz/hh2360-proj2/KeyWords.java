/**
 * keywords container
 * @author Joey
 *
 */
public class KeyWords {
	static String[] computerK = {"cpu","java","module","multimedia",
		"perl","vb","agp card","application windows",
		"applet code","array code","audio file",
		"avi file","bios","buffer code","bytes code",
		"shareware","card drivers","card graphics",
		"card pc","pc windows"};
	
	static String[] HealthK = {"acupuncture",
		"aerobic",
		"aerobics",
		"aids",
		"cancer",
		"cardiology",
		"cholesterol",
		"diabetes",
		"diet",
		"fitness",
		"hiv",
		"insulin",
		"nurse",
		"squats",
		"treadmill",
		"walkers",
		"calories fat",
		"carb carbs",
		"doctor health",
		"doctor medical",
		"eating fat",
		"fat muscle",
		"health medicine",
		"health nutritional",
		"hospital medical",
		"hospital patients",
		"medical patient",
		"medical treatment",
		"patients treatment",
	};
	static String[] SportsK = {
		"laker",
		"ncaa",
		"pacers",
		"soccer",
		"teams",
		"wnba",
		"nba",
		"avg league",
		"avg nba",
		"ball league",
		"ball referee",
		"ball team",
		"blazers game",
		"championship team",
		"club league",
		"fans football",
		"game league"};

	static String[] HardwareK = {
		"bios", 
		"motherboard", 
		"board fsb", 
		"board overclocking", 
		"fsb overclocking", 
		"bios controller ide",
		"cables drive floppy"
};
	
	static String[] ProgrammingK = {
		"actionlistener", 
		"algorithms", 
		"alias", 
		"alloc", 
		"ansi", 
		"api", 
		"applet", 
		"argument", 
		"array", 
		"binary", 
		"boolean", 
		"borland", 
		"char", 
		"class", 
		"code", 
		"compile", 
		"compiler", 
		"component",
		"container", 
		"controls", 
		"cpan", 
		"java", 
		"perl"
};
	static String[] DiseasesK = {
		"aids", 
		"cancer", 
		"dental", 
		"diabetes", 
		"hiv", 
		"cardiology", 
		"aspirin cardiologist", 
		"aspirin cholesterol", 
		"blood heart", 
		"blood insulin", 
		"cholesterol doctor", 
		"cholesterol lipitor", 
		"heart surgery", 
		"radiation treatment" 		
	};
	static String[] FitnessK = {
		"aerobic", 
		"fat", 
		"fitness", 
		"walking", 
		"workout", 
		"acid diets", 
		"bodybuilding protein", 
		"calories protein", 
		"calories weight", 
		"challenge walk", 
		"dairy milk", 
		"eating protein", 
		"eating weight", 
		"exercise protein", 
		"exercise weight" 		
	};
	
	static String[] SoccerK = {
		"uefa",
		"leeds",
		"bayern",
		"bundesliga",
		"premiership",
		"lazio",
		"mls",
		"hooliganism",
		"juventus",
		"liverpool",
		"fifa"		
	};
	static String[] BasketballK = {
		"nba",
		"pacers",
		"kobe",
		"laker",
		"shaq" ,
		"blazers",
		"knicks",
		"sabonis",
		"shaquille",
		"laettner",
		"wnba",
		"rebounds",
		"dunks"		
	};
}

