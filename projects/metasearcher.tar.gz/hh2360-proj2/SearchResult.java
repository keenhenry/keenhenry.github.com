import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This class is used for formatting search results
 * returned by Yahoo! Open Search Service.
 * @author: Henry Huang
 * @date: 02/17/2010 
 */

public class SearchResult {
	private String title;
	private String URL;
	private String summary;
	private boolean relevant;
	/**
	 * Transform a <result> element in XML DOM into a SearchResult object
	 * @rElmnt: a <result> element
	 * @return: returns the SearchResult of corresponding <result> element 
	 */ 
	public static SearchResult getSearchResult(Element rElmnt)
	{
		String summary 	= getTextValue(rElmnt, "abstract");
		String title 	= getTextValue(rElmnt, "title");
		String url 	= getTextValue(rElmnt, "url");

		return new SearchResult(title, url, summary, false);
	}
	/**
	 * Get the text value of an element with the corresponding tagName
	 * @tagName: the name of the tag
	 * @e: <result> element 
	 * @return: returns the text value stored in that tag 
	 */ 
	private static String getTextValue(Element e, String tagName) 
	{
		NodeList nlist 	= e.getElementsByTagName(tagName);
		Element  tmp 	= (Element) nlist.item(0);
		Node	 node	= tmp.getFirstChild();
		String   text   = null;	 

		// Some abstract text is not present in abstract tag
		if (node == null) 
			text = "";
		else
			text = (node.getNodeValue()).replaceAll("<[^>]*>", "");	// remove HTML tags in text

		return text;
	}
	
	public SearchResult(String t, String u, String s, boolean r)
	{
		this.title 	= t;
		this.URL 	= u;
		this.summary 	= s;
		this.relevant	= r;
	}

	public void setRelevance(boolean value)
	{
		relevant = value;
	}
	
	public boolean getRelevance()
	{
		return relevant;
	}

	public String toString()
	{
		return "[\n URL: " + URL + "\n Title: " + title + "\n Summary: " + summary + "\n]";
	}
	
	/**
	 * return title (by joe)
	 * @return
	 */
	public String getTitle(){
		return title;
	}
	
	/**
	 * return url (by Henry)
	 * @return
	 */
	public String getURL(){
		return URL;
	}
}
