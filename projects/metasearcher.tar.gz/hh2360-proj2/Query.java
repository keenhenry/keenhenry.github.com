/**
 * Query object for yahoo boss
 * @author Joey
 *
 */
public class Query {

	private static String mYahooAppId = null;
	
	private String mURI;
	/**
	 * set global yahoo ID(default value for yahoo ID)
	 * @param yahooAppId
	 */
	public static void setYahooID(String yahooAppId){
		mYahooAppId = yahooAppId;
	}
	/**
	 * Obtain the query instance
	 * @param DB
	 * @param query
	 * @param yahooAppId
	 * @return
	 */
	public static Query makeQuery(String DB, String query, String yahooAppId){
		String id;
		if(yahooAppId == null && mYahooAppId == null){
			System.out.println("Please specify yahoo ID");
			System.exit(0);
		}
		id = (yahooAppId!=null)?yahooAppId:mYahooAppId;
		String 	ARGUMENT= "?appid=".concat(id).concat("&format=xml").concat("&count=4").concat("&sites=").concat(DB);
		//String 	ARGUMENT= "?appid=".concat(id).concat("&format=xml");
		String REQUEST	 = "/ysearch/web/v1/".concat(query.replaceAll(" ", "%20")).concat(ARGUMENT);
		//String URI	 = "http://boss.yahooapis.com".concat(REQUEST);	
		//System.out.println(REQUEST);
		Query q= new Query();
		q.setURI(REQUEST);
		return q;
	}
	
	@Override
	public String toString() {
		return mURI;
	}
	private void setURI(String uri){
		mURI = uri;
	}
}
