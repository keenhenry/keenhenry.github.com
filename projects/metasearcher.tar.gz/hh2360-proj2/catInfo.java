import java.util.Vector;

public class catInfo {
	String catInfo;
	Vector<keywordDocs>  docsList = new Vector<keywordDocs>();
	
	public static class keywordDocs{
		String keyWord;
		Vector<SearchResult> docs = new Vector<SearchResult>();
		int totalHit;
	}

	// added by Henry; for debugging purpose
	public String toString() {
		return catInfo;
	}
}
