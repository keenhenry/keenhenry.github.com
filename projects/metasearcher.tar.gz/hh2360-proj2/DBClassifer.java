import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.lang.Double;
import java.util.Vector;
/**
 * DB classifier 
 * @author Joey
 *
 */
public class DBClassifer {
	HTTPClient mHttpAgent;
	classificationTree mTree;
	DBClassifer(HTTPClient httpAgent, classificationTree Tree){
		mHttpAgent = httpAgent;
		mTree = Tree;
	}
	/**
	 * entry method for classification
	 * @param dbPath
	 * @param tec
	 * @param tes
	 */
	public Vector<String> classify(String dbPath,double tec,double tes,Vector<catInfo> list){

		classificationTree.cNode root = mTree.getRoot();
		Vector<String> result = classifyImpl(root,dbPath,tec,tes,1,list);
		return result;

	}
	/**
	 * calssification recursive method
	 * @param cat
	 * @param db
	 * @param tec
	 * @param tes
	 * @param specificity
	 * @return
	 */
	private Vector<String> classifyImpl(classificationTree.cNode cat, String db,
				double tec, double tes, double specificity,Vector<catInfo> list){
		Vector<Integer> ConverageVector = new Vector<Integer>();
		Vector<Double> SpecificityVector = new Vector<Double>();
		if(cat.isLeaf()){
			Vector<String> ret = new Vector<String>();
			ret.add(cat.getClassName());
			return ret;
		}
		// retrive all of children
		Vector<classificationTree.cNode> childrenList = 
			cat.getChildren();
		// obtain matched number in each child
		int totalConverage = 0;
		catInfo info = new catInfo(); //question
		info.catInfo = cat.getClassName();
		for(int i=0;i<childrenList.size();i++){
			int num = getCatogoryDocs(db,childrenList.get(i),info);
			//int num = numMatchForCatogory(db,childrenList.get(i));
			ConverageVector.add(num);
			totalConverage += num;
		}
		// for debuging
		/*System.out.println(info.catInfo+":");
		for(int j=0;j<info.docsList.size();j++){
			System.out.println(info.docsList.get(j).keyWord+"("+info.docsList.get(j).totalHit+"):");
			for(int k=0;k<info.docsList.get(j).docs.size();k++){
				System.out.println(info.docsList.get(j).docs.get(k).getTitle());
			}
		}*/
		list.add(info);
		//calculate Specificity vector
		for(int i=0;i<childrenList.size();i++){
			double res = specificity * (double)ConverageVector.get(i);
			res /=(double)totalConverage; 
			SpecificityVector.add(res);
		}
		for(int i=0;i<childrenList.size();i++){
		System.out.println(childrenList.get(i).getClassName()+
				":Converage = "+ConverageVector.get(i)+" and Specificity="+SpecificityVector.get(i));
		}
		// Push down
		Vector<String> result = new Vector<String>();
		for(int i=0;i<childrenList.size();i++){
			if(SpecificityVector.get(i) > tes && 
					ConverageVector.get(i) > tec){
				Vector<String> ret = classifyImpl(childrenList.get(i),db,tec,tes,
						SpecificityVector.get(i),list);
				for(int j =0;j<ret.size();j++){
					result.add(cat.getClassName()+"->"+ret);
				}
			}
		}
		if(result.size()==0){
			Vector<String> ret = new Vector<String>();
			ret.add(cat.getClassName());
			return ret;
		}
		else
			return result;
		}
	/**
	 * return number of documents that belongs to the catgory and fill in catInfo
	 * @param node
	 * @return
	 */
	private int getCatogoryDocs(String db, classificationTree.cNode node, catInfo info){
		int res = 0;
		Vector<String> keyWords = node.getQueryWords();
		for(int i=0;i<keyWords.size();i++){
			Query q = Query.makeQuery(db, keyWords.get(i),null);
			Element doc = getDoc(q);
			int hit = getTotalNum(doc);
			res += hit;
			catInfo.keywordDocs kDocs= new catInfo.keywordDocs();
			kDocs.keyWord = keyWords.get(i);
			kDocs.docs = getDocs(doc);
			kDocs.totalHit = hit;
			info.docsList.add(kDocs);

		}
		return res;
	}
	/**
	 * obtain root of document object obtained by the query
	 * @param q
	 * @return
	 */
	private Element getDoc(Query q){
		Element root = null;
		try{
			root = mHttpAgent.getYahooResponse(q.toString());
	}catch(Exception e){
		System.err.println(e);
		System.err.println("get number of results faild");			
	}
	return root;
	}
	/**
	 * return number of results matched in the root object
	 * @param q
	 * @return
	 */
	private int getTotalNum(Element root){
		int num = -1;
		try{
			String numString = root.getElementsByTagName("resultset_web").item(0).
				getAttributes().getNamedItem("totalhits").getNodeValue(); 
			num = Integer.parseInt(numString);
		}catch(Exception e){
			System.err.println(e);
			System.err.println("get number of results faild");			
		}
		return num;
	}	
	/**
	 * return docs in the root object
	 * @param root
	 * @return
	 */
	private Vector<SearchResult> getDocs(Element root){
		NodeList nlist = root.getElementsByTagName("result");
		Vector<SearchResult> ret = new Vector<SearchResult>();
		if (nlist != null && nlist.getLength() > 0) {
			for (int i = 0; i < nlist.getLength()&&i <4; ++i) {
				Element e = (Element) nlist.item(i);	// get the result element
				SearchResult res = SearchResult.getSearchResult(e);  // get the SearchResult object				
				ret.add(res);
			}
		}
		return ret;
	}
	/**
	 * return number of documents that belongs to the catgory
	 * @param node
	 * @return
	 */
	private int numMatchForCatogory(String db, classificationTree.cNode node){
		int res = 0;
		Vector<String> keyWords = node.getQueryWords();
		for(int i=0;i<keyWords.size();i++){
			Query q = Query.makeQuery(db, keyWords.get(i),null);
			res += getNumResult(q);
		}
		return res;
	}
	/**
	 * return number of results matched for specificed query
	 * @param q
	 * @return
	 */
	private int getNumResult(Query q){
		int num = -1;
		try{
			//TODO: assumption: it will definitely return resultset_web element
			Element root = mHttpAgent.getYahooResponse(q.toString());
			String numString = root.getElementsByTagName("resultset_web").item(0).
				getAttributes().getNamedItem("totalhits").getNodeValue(); 
			num = Integer.parseInt(numString);
		}catch(Exception e){
			System.err.println(e);
			System.err.println("get number of results faild");			
		}
		return num;
	}
	/**
	 * program entry point
	 * @param args
	 */
	public static void main(String[] args) {
		double tes;
		double tec;
		Vector<catInfo> list = new Vector<catInfo>();
		String dbPath;
		HTTPClient	httpAgent = null;
		if(args.length!=4){
			System.err.println("Arguments are invalid");
			System.exit(0);
		}
		
		dbPath = args[1];
		tec = Double.parseDouble(args[2]);
		tes = Double.parseDouble(args[3]);
	try{
		//new http agent
		httpAgent	= new HTTPClient();
		// set global yahoo ID
		Query.setYahooID(args[0]);
	} catch (ParserConfigurationException pe) {
		System.err.println(pe);
		System.err.println("");
	} catch(SAXException se) {
		System.err.println(se);
		System.err.println("");		
	} catch (Exception e) {
		System.err.println(e);
		System.err.println("");				
	}
	// obtain classification tree
	classificationTree tree = classificationTree.getTree();
	// new classifer
	DBClassifer Classifer = new DBClassifer(httpAgent,tree);
	// start classfying
	System.out.println("classifying.....");
	Vector<String> result = Classifer.classify(dbPath,tec,tes,list);
	System.out.println("Classification:");
	System.out.println(result);

	/**
	 * Added by Henry Huang
	 */ 
	ContentSummary dbcs = new ContentSummary(list, dbPath);
	dbcs.CSGenerator();	
	}

}
