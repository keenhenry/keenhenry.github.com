import java.util.*;

/** A data structure for a term vector for a document stored
 * as a HashMap that maps tokens to Weight's that store the
 * weight of that token in the document.
 */

public class HashMapVector {
    /** The HashMap that stores the mapping of tokens to Weight's */
    public HashMap<String,Weight> hashMap = new HashMap<String,Weight>();

    private String highestToken;
    private String secHighestToken;
    /** Returns the number of tokens in the vector.
     */
    public int size () {
	return hashMap.size();
    }

    /** Clears the vector back to all zeros
     */
    public void clear () {
	hashMap.clear();
    }

    /** Returns the Set of MapEntries in the hashMap  
     */
    public Set<Map.Entry<String,Weight>> entrySet() {
	return hashMap.entrySet();
    }

    /** Increment the weight for the given token in the vector by the given amount.
     */
    public double increment(String token, double amount) {
	Weight weight = hashMap.get(token);
	if (weight == null) {
	    // If there is no current Weight for this token, create one
	    weight = new Weight();
	    hashMap.put(token,weight);
	    }
	// Increment the weight of this token in the bag.
	weight.increment(amount);
	return weight.getValue();
    }

    /** Return the weight of the given token in the vector */
    public double getWeight(String token) {
	Weight weight = hashMap.get(token);
	if (weight == null) 
	    return 0.0;
	else
	    return weight.getValue();
    }

    /** Increment the weight for the given token in the vector by 1.
     */
    public double increment(String token) {
	return increment(token, 1.0);
    }

    /** Increment the weight for the given token in the vector by the given int
     */
    public double increment(String token, int amount) {
	return increment(token, (double)amount);
    }

    /** add the given vector to the current vector */
    public void add(HashMapVector vector) {
	for (Map.Entry<String,Weight> entry : vector.entrySet()) {
	    // An entry in the HashMap maps a token to a Weight
	    String token = entry.getKey();
	    // The weight for the token is in the value of the Weight
	    double weight = entry.getValue().getValue();
	    increment(token, weight);
	}
    }

    /** add a scaled version of the given vector to the current vector */
    public void addScaled(HashMapVector vector, double scalingFactor) {
	for (Map.Entry<String,Weight> entry : vector.entrySet()) {
	    // An entry in the HashMap maps a token to a Weight
	    String token = entry.getKey();
	    // The weight for the token is in the value of the Weight
	    double weight = entry.getValue().getValue();
	    increment(token, scalingFactor * weight);
	}
    }

    /** subtract the given vector from the current vector */
    public void subtractScaled(HashMapVector vector, double scalingFactor) {
	for (Map.Entry<String,Weight> entry : vector.entrySet()) {
	    // An entry in the HashMap maps a token to a Weight
	    String token = entry.getKey();
	    // The weight for the token is in the value of the Weight
	    double weight = entry.getValue().getValue();
	    increment(token, -(scalingFactor * weight));
	}
    }
	
    /** subtract the given vector from the current vector */
    public void subtract(HashMapVector vector) {
	for (Map.Entry<String,Weight> entry : vector.entrySet()) {
	    // An entry in the HashMap maps a token to a Weight
	    String token = entry.getKey();
	    // The weight for the token is in the value of the Weight
	    double weight = entry.getValue().getValue();
	    increment(token, -weight);
	}
    }
    
    /** multiply the vector by a constant */
    public void multiply(double factor) {
	for (Map.Entry<String,Weight> entry : entrySet()) {
	    
	    Weight weight = entry.getValue();
	    weight.setValue(factor * weight.getValue());
	}
    }
	
    
    /** compute highest two token. */
    public void computeHighestTwo() {
	double maxWeight = Double.NEGATIVE_INFINITY;
	for (Map.Entry<String,Weight> entry : entrySet()) {
	    // The weight for the token is in the value of the Weight
	    double weight = entry.getValue().getValue();
	    if (weight > maxWeight){
	    	maxWeight = weight;
	    	highestToken = entry.getKey();
	    }
	}
	double secMaxWeight = Double.NEGATIVE_INFINITY;
	for (Map.Entry<String,Weight> entry : entrySet()) {
	    // The weight for the token is in the value of the Weight
	    double weight = entry.getValue().getValue();
	    if (!entry.getKey().equals(highestToken) && weight > secMaxWeight){
	    	secMaxWeight = weight;
	    	secHighestToken = entry.getKey();
	    }
	}
    }
    /** get Highest score term 
     * (called after computeHighestTwo)
     */
    public String getHighest(){
    	return highestToken;
    }
    /** get second Highest score term* 
     * (called after computeHighestTwo)/
     */
	public String getSec(){
		return secHighestToken;
	}

    /** Print out the feedback summary 
     *  - by Henry */
    public void print(String oQuery, String mQuery, double prec, double target) {
	System.out.println("======================\nFEEDBACK SUMMARY");
        System.out.println("Query " + oQuery);	
        System.out.println("Precision " + prec);	
        if (prec < target) {
		System.out.println("Still below the desired precision " + target);
		System.out.println("Indexing results ...\nIndexing results ...");
		System.out.println("Augmenting by " + mQuery);
		if (prec == 0.0)
			System.out.println("Below desired precision, but can no longer augment the query");
	} else {	
		System.out.println("Desired precision reached, done");
	}
/*	for (Map.Entry<String,Weight> entry : entrySet()) {
	    // Print the term and its weight.
	    System.out.println(entry.getKey() + ":" + entry.getValue().getValue());
	}*/
    }

    /** Return String having all of the tokens with their weights */
    public String toString() {
	String ret = "";
	for (Map.Entry<String,Weight> entry : entrySet()) {
	    // Print the term and its weight.
	    ret += entry.getKey() + "#" + entry.getValue().getValue() + "\n";	// modified by Henry
	}
	return ret;
    }


    /** Compute Euclidian length (sqrt of sum of squares) of vector */
    public double length() {
	// Stores running sum of squares
	double sum = 0;
        for (Map.Entry<String,Weight> entry : entrySet()) {
	    // An entry in the HashMap maps a token to a Weight
	    double weight = entry.getValue().getValue();
	    sum += weight * weight;	    
	}
	return Math.sqrt(sum);
    }
}
