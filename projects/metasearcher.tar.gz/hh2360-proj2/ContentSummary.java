/**
 * this program is to produce content summary of a database
 * @author: Henry Huang
 * @date: 03/17/2010 
 */

import java.util.*;
import java.io.File;
import java.io.PrintWriter;

public class ContentSummary {
	private Vector<catInfo> catList = null;
	private String DBName;				// Name of database for content summary 

	ContentSummary (Vector<catInfo> list, String host) {
		catList = list;
		DBName	= host;
		parseCatInfoList();
	}
	/**
	 * Content Summary Genrator: Generate content summary for each node
	 */ 
	public void CSGenerator() {
		for(int i = 0; i < catList.size(); i++) 
			ContentSummaryGeneration(catList.get(i), HashOneCat(catList.get(i)));	
		
		System.out.println("\n\nComplete!");
	}
	/**
	 * Build a content summary for a single category
	 * @node: a catetory (catInfo data structure)
	 * @return: a HashMapVector
	 */ 
	private HashMapVector HashOneCat(catInfo node) {
		HashSet<String> NonRepeatedURLS = new HashSet(350);	// Non-repeated URLs 
		HashMapVector cs = new HashMapVector();			// content summary for this node
		Vector<SearchResult> vsr;				// vector of SearchResult objects
	
		/* Building a hash of non-repeated URLs: eliminated repeated documents */
		for (int i = 0; i < node.docsList.size(); i++) {
			vsr = node.docsList.get(i).docs;
			for (int j = 0; j < vsr.size(); j++) 
				NonRepeatedURLS.add(vsr.get(j).getURL()); 
		}
	
		Iterator<String> url  	= NonRepeatedURLS.iterator();	
		Set 		 words 	= null;			// Set of words returned by lynx
		Iterator<String> word 	= null;	
		String		 link	= null;

		/** 
		 * retrieve documents from databases 
		 * and build a word-DF table
		 **/	
		try {
			while (url.hasNext()) {
				link = url.next();
				System.out.println("Getting document: " + link);
				words = getWordsLynx.runLynx(link);
				word = words.iterator();
				
				while(word.hasNext()) 
					cs.increment(word.next());
				
				Thread.sleep(1000);		// pause program for 1.0 seconds
			}
		} catch (InterruptedException ie) {
			System.err.println(ie);
		}

		return cs;
	}
	/**
	 * Sort the elements in HashMapVector and dump the results into a .txt file
	 * @cat: catInfo
	 * @conSum: HashMapVector
	 */
       	private void ContentSummaryGeneration (catInfo cat, HashMapVector conSum) {
		/* firt thing: to sort the HashMap using a SortedMap */
		TreeMap<String, Weight> cs = new TreeMap(conSum.hashMap);

		/* generate content texts */
		String content = "";
		for (Map.Entry<String, Weight> entry : cs.entrySet()) 
	    		content += entry.getKey() + "#" + entry.getValue().getValue() + "\n";
		
		/* produce content summary into a .txt file */
		String 		fileName = cat.catInfo + "-" + DBName + ".txt";
		File 		newFile;
		PrintWriter 	output;

		try {
			newFile = new File(fileName);
			output 	= new PrintWriter(newFile);
			output.print(content);
			output.flush();
		} catch (Exception e) {
			System.err.println(e);
		}
	}	
	/**
	 * To parse catinfo list so that each node has all 
	 * the information it needs to generate content summary 
	 */ 
	private void parseCatInfoList() {
		if(catList.size() > 1) {
			for (int i = 1; i < catList.size(); i++)
				catList.get(0).docsList.addAll(catList.get(i).docsList);
		}
	}
}
