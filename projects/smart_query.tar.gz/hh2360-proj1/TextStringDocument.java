import java.io.*;
import java.util.*;

/** 
 * A document represented by a String
 */
public class TextStringDocument {

    /** StringTokenizer delim for tokenizing only alphabetic strings. */
    public static final String tokenizerDelim = " \t\n\r\f\'\"\\1234567890!@#$%^&*()_+-={}|[]:;<,>.?/`~";

    /** The tokenizer for this document. */
    protected StringTokenizer tokenizer = null;
    /** The next token in the document */    
    protected String nextToken = null;
    /** The number of tokens currently read from document */
    protected int numTokens = 0;
    /** Create a simple Document for this string */
    public TextStringDocument(String string) {
	this.tokenizer = new StringTokenizer(string, tokenizerDelim);
	prepareNextToken();
    }
    /** Returns a hashmap version of the term-vector (bag of words) for this
     * document, where each token is a key whose value is the number of times 
     * it occurs in the document as stored in a Weight.
     * @see Weight
     */
    public HashMapVector hashMapVector () {
	if (numTokens != 0)
	    return null;
	HashMapVector vector = new HashMapVector();
	// Process each token in the document and add it to the vector
	while (hasMoreTokens()) {
	    String token = nextToken();
	    vector.increment(token);
	}
	return vector;
    }    
    /** Returns true iff the document contains more tokens */
    public boolean hasMoreTokens() {
	if (nextToken == null)
	    return false;
	else
	    return true;
    }

    /** Returns the next token in the document or null if there are none */
    public String nextToken() {
	String token = nextToken;
	if (token == null) return null;
	prepareNextToken();
	numTokens++;
	return token;
    }

    /** Get the next token from this string */
    protected String getNextCandidateToken() {
	if (tokenizer == null || !tokenizer.hasMoreTokens()) 
	    return null;
	return tokenizer.nextToken();
    }
    

    /** The nextToken slot is always precomputed and stored by this method.
     * Performs stop-word removal of candidate tokens. */
    protected void prepareNextToken () {
	// Loop until a non-stopword token is found
	do {
	    nextToken = getNextCandidateToken();
	    if (nextToken == null) return; // reached end of document
	    // Normalize token string case to lower case.
	    nextToken = nextToken.toLowerCase();
	}
	while (nextToken == null);
    }
}
