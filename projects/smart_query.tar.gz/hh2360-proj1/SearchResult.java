/**
 * This class is used for formatting search results
 * returned by Yahoo! Open Search Service.
 * @author: Henry Huang
 * @date: 02/17/2010 
 */

public class SearchResult {
	private String title;
	private String URL;
	private String summary;
	private boolean relevant;

	public SearchResult(String t, String u, String s, boolean r)
	{
		this.title 	= t;
		this.URL 	= u;
		this.summary 	= s;
		this.relevant	= r;
		//this.result	= "";
	}

	public void setRelevance(boolean value)
	{
		relevant = value;
	}
	
	public boolean getRelevance()
	{
		return relevant;
	}

	public String toString()
	{
		return "[\n URL: " + URL + "\n Title: " + title + "\n Summary: " + summary + "\n]";
	}
	
	/**
	 * return title (by joe)
	 * @return
	 */
	public String getTitle(){
		return title;
	}
}
