/**
 * This is a simple HTTP client that receives
 * Yahoo! XML response and parse it into a queue
 * @author: Henry Huang  
 * @date: 02/17/2010 
 */

import java.io.*;
import java.util.LinkedList;
import java.util.ListIterator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class HTTPClient {
	private String   servName 		= "boss.yahooapis.com"; 
	private Document DOM			= null;
	private Element  doc			= null;
	private NodeList nlist			= null;
	private DocumentBuilderFactory factory 	= null;
	private DocumentBuilder builder 	= null;
	
	/**
	 * Construct a HTTP object 
	 */ 
	public HTTPClient() throws ParserConfigurationException, SAXException, IOException
	{
		// get the factory
		factory = DocumentBuilderFactory.newInstance();
		
		// get an instance of document builder
		builder = factory.newDocumentBuilder();
	}
	
	/**
	 * Get Yahoo XML response and parse in into DOM structure
	 * @return: number of responses returned by Yahoo 
	 */ 
	public int getYahooResponse(String REQ) throws SAXException, IOException 
	{
		int resNum = 0;

		DOM   = builder.parse("http://".concat(servName).concat(REQ));	// parse the XML response into a DOM structure 
		doc   = DOM.getDocumentElement(); 				// get the root element
		nlist = doc.getElementsByTagName("result"); 			// get a nodelist of <result> elements	
		
		if ((resNum = nlist.getLength()) < 10);
		else 	
			System.out.println("Total # of results: " + resNum + "\nYahoo! Search Results: \n======================\n"); 
		
		return resNum;
	}

	/**
	 * do relevance feedback and write transcripts
	 * @query: user query
	 * @round: round number 
	 * @q: a queue to store the search results
	 * @return: returns the precision@10 of current iteration 
	 */ 
	public double RelevanceFeedBack(String query, int round, LinkedList<SearchResult> q) throws 
					ParserConfigurationException, SAXException, IOException
	{
		// parse dom object and set up SearchResults objects
		parseDocument(q);

		// writing results to a transcript
		return writeTranscript(query, round, q);
	}

	/**
	 * Parse XML DOM into SearchResult objects and store them into a queue
	 * @q: a queue to store the search results
	 */ 
	private void parseDocument(LinkedList<SearchResult> q) throws IOException 
	{
		if (nlist != null && nlist.getLength() > 0) {
			for (int i = 0; i < nlist.getLength(); ++i) {
				Element e = (Element) nlist.item(i);	// get the result element
				SearchResult res = getSearchResult(e);  // get the SearchResult object
				promptUser(i + 1, res, q);
				System.out.println();
			}
		}	
	}
	
	/**
	 * The function that really does relevance feedback 
	 * @res: SearchResult object
	 * @rn: result number 
	 * @q: a queue to store the search results
	 */ 
	private void promptUser(int rn, SearchResult res, LinkedList<SearchResult> q) throws IOException
	{
		BufferedReader is = new BufferedReader(new InputStreamReader(System.in));
		String userInput;
		
		System.out.print("Result " + rn + "\n\n" + res + "\n\nRelevant (Y/N)? ");
		
		userInput = is.readLine();
		if (userInput.equalsIgnoreCase("y") || userInput.equalsIgnoreCase("yes")) 
			res.setRelevance(true);
		
		q.addLast(res);
	}

	/**
	 * Transform a <result> element in XML DOM into a SearchResult object
	 * @rElmnt: a <result> element
	 * @return: returns the SearchResult of corresponding <result> element 
	 */ 
	private SearchResult getSearchResult(Element rElmnt)
	{
		String summary 	= getTextValue(rElmnt, "abstract");
		String title 	= getTextValue(rElmnt, "title");
		String url 	= getTextValue(rElmnt, "url");

		return new SearchResult(title, url, summary, false);
	}

	/**
	 * Get the text value of an element with the corresponding tagName
	 * @tagName: the name of the tag
	 * @e: <result> element 
	 * @return: returns the text value stored in that tag 
	 */ 
	private String getTextValue(Element e, String tagName) 
	{
		NodeList nlist 	= e.getElementsByTagName(tagName);
		Element  tmp 	= (Element) nlist.item(0);
		Node	 node	= tmp.getFirstChild();
		String   text   = null;	 

		// Some abstract text is not present in abstract tag
		if (node == null) 
			text = "";
		else
			text = (node.getNodeValue()).replaceAll("<[^>]*>", "");	// remove HTML tags in text

		return text;
	}

	/**
	 * Record the results of relevance feedback in a transcript 
	 * @query: user query
	 * @round: round number 
	 * @q: a queue to store the search results
	 * @return: returns the precision@10 of current iteration 
	 */ 
	private double writeTranscript(String query, int round, LinkedList<SearchResult> q) throws IOException
	{
		BufferedWriter OUT 	= new BufferedWriter(new FileWriter("transcript.txt", true));
		SearchResult   tmp	= null;
		int 	       relCount	= 0;		
		double 	       precAt10	= -1.0;

		String report = "=====================================";
		report += "\nROUND " + round + "\nQUERY " + query + "\n";

		ListIterator<SearchResult> it = q.listIterator(0);
		for (int i = 1; it.hasNext(); ++i) {
			report += "\nResult " + i + "\nRelevant: ";
			tmp = it.next();	
			
			if (tmp.getRelevance()) {
				report += "YES\n";
				++relCount;
			} else {
				report += "NO\n";
			}

			report += (tmp + "\n\n");
		}
		
		precAt10 = (double) relCount / 10;

		report += "PRECISION " + precAt10 + "\n";
		
		OUT.write(report, 0, report.length());
		OUT.flush();
		OUT.close();

		return precAt10;
	}
}
