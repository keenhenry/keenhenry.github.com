/**
 * this is a query expander 
 * @author: joe
 * @date: 02/19/2010 
 */

import java.util.Map;
import java.util.Set;
import java.util.Vector;

public class QueryExpander {
	public static double weightRel = 0.5;
	public static double weightNonRel = 0.5;
	private String oQuery;
        private double prec;		// add by Henry	
        private double targetPrec;	// add by Henry
	private Vector<HashMapVector> mRelevantSet = 
		new Vector<HashMapVector>();
	private Vector<HashMapVector> mNonRelevantSet = 
		new Vector<HashMapVector>();
	private String mQuery = "";
	public void setQuery(String query){
		oQuery = query;
	}
	/**
	 * pass in precision information of the current information 
	 * so that feedback summary can be displayed on the console
	 * @author: Henry
	 */ 
	public void setPrecision(double Prec, double tarPrec){
		prec = Prec;
		targetPrec = tarPrec;
	}
	/**
	 * insert this document to relevant set
	 * @param doc
	 */
	public void insertToRelevantSet(String doc){
		HashMapVector docVector = (new TextStringDocument(doc)).hashMapVector();
		mRelevantSet.add(docVector);
	}
	/**
	 * insert this document to non-relevant set
	 * @param doc
	 */
	public void insertToNonRelevantSet(String doc){
		HashMapVector docVector = (new TextStringDocument(doc)).hashMapVector();
		mNonRelevantSet.add(docVector);
	}
	public static int ifContain(String source,String token){
		String[] q = source.split(" ");
		for(int i=0;i<q.length;i++){
			if(q[i].equals(token))
				return i;
		}
		return -1;
	}
	public static String elimiate(String source,int whichOne){
		String[] q = source.split(" ");
		q[whichOne] = "";
		String ret = "";
		for(int i=0;i<q.length;i++){
			if(!q[i].equals("")){
				if(i == 0)
					ret = q[i];
				else
					ret = ret+" "+q[i];
			}
		}		
		return ret;
	}
	/**
	 * compute the expanded query
	 * @param wRelevant
	 * @param wNonRelevant
	 * @return
	 */
	public String computeExpandQuery
	(double wRelevant,double wNonRelevant){
		
		HashMapVector res = new HashMapVector();
		HashMapVector nores = new HashMapVector();
		for(int i=0;i<mRelevantSet.size();i++){
			// Normalize the vector
			HashMapVector v = mRelevantSet.get(i);
			double len = v.length();
			res.addScaled(v, 1/len);
		}
		
		res.multiply(1/(double)mRelevantSet.size());
		res.multiply(wRelevant);

		for(int i=0;i<mNonRelevantSet.size();i++){
			// Normalize the vector
			HashMapVector v = mNonRelevantSet.get(i);
			double len = v.length();
			nores.subtractScaled(v, 1/len);
		}		
		nores.multiply(1/(double)mNonRelevantSet.size());
		nores.multiply(wNonRelevant);	// shouldn't it be nores.multiply(wNonRelevant)? Henry
		// sum up to vectors
		res.add(nores);
		//get highest two words
		res.computeHighestTwo();
		String one = res.getHighest();
		String two = res.getSec();
		double weight;
		if(one != null){
			weight = res.getWeight(one);
			if(weight > 0){
				if(ifContain(mQuery,one)<0&&ifContain(oQuery,one)<0){
					if(mQuery.equals(""))
						mQuery = one;
					else
						mQuery = mQuery+" "+one;	// modified by Henry
				}
		
			}
		}
		if(two != null){
			weight = res.getWeight(two);
			if(weight > 0){
				if(ifContain(mQuery,two)<0&&ifContain(oQuery,two)<0){
					if(mQuery.equals(""))
						mQuery = two;
					else
						mQuery = mQuery+" "+two;	// modified by Henry
				}
			}
		}
		// elimate some words
		Set<Map.Entry<String,Weight>> set = res.entrySet();
		String[] q = mQuery.split(" ");
		for(Map.Entry<String,Weight> entry : set){
			if(entry.getValue().getValue()<0){
				int whichOne = ifContain(mQuery,entry.getKey());
				if(whichOne > 0)
					mQuery = elimiate(mQuery,whichOne);
			}
		}
		
		res.print(oQuery, mQuery, prec, targetPrec);
		return (oQuery+" "+mQuery);
	}
	/**
	 * clear up
	 */
	public void clear(){
		mRelevantSet.clear();
		mNonRelevantSet.clear();
	}
}
