/**
 * This is an IR system integrated with Yahoo Open Search Service
 * by Yahoo BOSS API. This IR system also implemented relevance 
 * feedback feature to improve search results.
 * @author: Henry Huang and Joe Wu 
 * @date: 02/09/2010 
 */

import java.util.*;

public class SmartQueryIR {
    
    public static void main(String [] args)
    {
	try {    
		// parse user command line arguments    
		if (args.length != 3) 
			throw new IllegalArgumentException("Wrong number of arguments");
		
		int			 roundCount	= 1;	    
		int			 numOfResults	= 0;	
		double 			 precAt10  	= -1.0;
		double 	 		 precision	= Double.parseDouble(args[1]);
		String 			 query 		= args[0];
		String 			 yahooAppId	= args[2];
		String			 REQUEST	= null;
		String			 URI		= null;
		String 			 ARGUMENT	= "?appid=".concat(yahooAppId).concat("&format=xml");
		HTTPClient		 httpAgent	= new HTTPClient();
		LinkedList<SearchResult> queue		= new LinkedList<SearchResult>(); 
		QueryExpander 		 qExp		= new QueryExpander();	// create query expansion object

		qExp.setQuery(query);
		// entering iterations of querying answers from Yahoo!	
		while (precAt10 < precision && precAt10 != 0.0) {
			
			// forming requests and printing out parameters
			REQUEST	 = "/ysearch/web/v1/".concat(query.replaceAll(" ", "%20")).concat(ARGUMENT);
       			URI	 = "http://boss.yahooapis.com".concat(REQUEST);	
			System.out.println("Parameters:\nClient key = " + yahooAppId + 
				      	"\nQuery      = " + query + 
				      	"\nPrecision  = " + precision +
				      	"\nURL: " + URI); 
		
			// get yahoo responses	
			if ((numOfResults = httpAgent.getYahooResponse(REQUEST)) < 10)
					break;
			// Do relevance feedback with user
			precAt10 = httpAgent.RelevanceFeedBack(query, roundCount++, queue);			
			
			// Query expansion
			qExp.clear();
			for(Iterator lit = queue.iterator(); lit.hasNext();){
				SearchResult sr = (SearchResult)lit.next();
				if(sr.getRelevance())
					qExp.insertToRelevantSet(sr.getTitle());
				else
					qExp.insertToNonRelevantSet(sr.getTitle());
			}
			
			qExp.setPrecision(precAt10, precision);
			query = qExp.computeExpandQuery(QueryExpander.weightRel, QueryExpander.weightNonRel);
			queue.clear();	
		}	
	} catch (Exception e) {
		System.err.println(e);
		System.err.println("Usage: java SmartQueryIR <query> <precision> <yahoo appId>");
	}	
    } 
}
